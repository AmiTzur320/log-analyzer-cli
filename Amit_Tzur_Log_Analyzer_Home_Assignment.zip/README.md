# LogAnalyzer
A command-line tool for extracting and reporting events from log files
## Overview
LogAnalyzer is a Python command-line tool for analyzing structured log files and reporting event data based on user-defined filters.\
It supports flexible filtering by event type, log level, regular expressions, and optional time range.
The tool processes both standard and compressed log files.

## Features
* Filter log events by event type, level, regex pattern, and time range

* Supports .log and .log.gz files

* Outputs either a count of matches or the matching log lines

* Modular, readable code with unit tests

* User-friendly CLI with error handling and --help support

## Usage
### Command-line Arguments
1. --log-dir <path>: Path to the folder containing log files (required)

2. --events-file <path>: Path to the configuration file with event filters (required)

3. --from <timestamp>: (Optional) Start timestamp, format: YYYY-MM-DDTHH:MM:SS

4. --to <timestamp>: (Optional) End timestamp, format: YYYY-MM-DDTHH:MM:SS

### Example Usage
python LogAnalyzer.py --log-dir logs --events-file events_sample.txt --from 2025-06-01T10:00:00 --to 2025-06-01T15:00:00

### Example Filter Configuration File (events.txt)
TELEMETRY --count --pattern ^Iteration time:\s\d+\.\d+\ssec$\
DEVICE --count --level WARNING\
GNMI --level ERROR

### Example Log File
2025-06-01T14:03:05 INFO TELEMETRY Iteration time: 1793.845 sec\
2025-06-01T14:05:22 WARNING DEVICE detected high temperature of device c95fe73e-14db-4ef4-909d-0c1db67c41ee: 40C\
2025-06-01T14:10:00 ERROR GNMI unresponsive telemetry at endpoint http://SWX1:9001/low_freq_debug 

### Example Output
Event: TELEMETRY pattern [^Iteration time:\s\d+\.\d+\ssec$] count — matches: 1 entries\
Event: DEVICE level [WARNING] count — matches: 1 entries\
Event: GNMI level [ERROR] — matching log lines:\
2025-06-01T14:10:00 ERROR GNMI unresponsive telemetry at endpoint http://SWX1:9001/low_freq_debug

* Tests include edge cases (e.g., invalid filters, missing fields, time range boundaries).

## Design Considerations
### Modular code:
Each function has a single responsibility and is independently testable.

### Project structure:

* The main logic is contained in the primary script (LogAnalyzer.py).

* Helper functions are organized in a separate module (helper.py) for clarity and reuse.

* Automated tests are provided in a dedicated file (test_log_analyzer.py) to ensure correctness and simplify maintenance.

## Performance
* All filters are checked for every log line.

* Regular expressions are compiled once per filter.

* Log files are processed line by lineץ

* Note: The current implementation does not group filters by event type.
For better runtime performance (especially with many filters or very large logs),
filters could be grouped and only relevant filters checked for each line.



## User experience:

* Clear CLI interface using click.

* Informative error handling for invalid inputs or files.

* Output format matches the assignment specification.

## Known Issues

* Malformed filter lines in the config file are skipped with a warning.

* Log lines that do not match the expected format are ignored.





## Files
LogAnalyzer.py – Main script

helper.py – Helper functions (if used)

test_log_analyzer.py – Unit tests

events_sample.txt – Example filter file

output.txt - Output file for the example

logs/ – Example log directory